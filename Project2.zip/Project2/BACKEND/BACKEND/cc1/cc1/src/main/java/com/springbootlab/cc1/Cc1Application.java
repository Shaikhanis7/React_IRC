package com.springbootlab.cc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cc1Application {

	public static void main(String[] args) {
		SpringApplication.run(Cc1Application.class, args);
	}

}
